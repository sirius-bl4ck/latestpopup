<?php  include 'ringba_get_number.php';

        // Tags can be passed into Ringba for use in the IVR, routing decisions, and other applications.
        // The correct format is $tag['tag_name'] = "value"; Example: $tag['city'] = "New York";
        // You can add any number of tags you'd like.

        $tag['City'] = "New York";
        $tag['Source'] = "affiliate_1";
       
	
	$landingPageURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";


        // You can also grab URL Parameter data and pass it into the tags like this:
        //$tag['Click_ID'] = $_GET['cid'];


        // This functions grab the phone number from the pool and pass the tags to Ringba.

        $phone_number = ringba_get_pool_number($tag, $landingPageURL);


        // This function formats the phone number like a traditional TFN. Example (800) 123-4567

        $phone_number = format_number_tfn($phone_number);
$phonenumber = $phone_number; // +44-800-048-5348 //+1-844-622-2122
?>