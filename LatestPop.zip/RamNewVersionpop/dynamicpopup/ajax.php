<?php
date_default_timezone_set('US/Eastern');

if (isset($_POST["call"]) && $_POST["call"] == "counter" && isset($_POST["tid"]) && isset($_POST["tip"])) {    
    $t_id = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tid"]);
    $t_ip = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tip"]); 
  $params_1= $_POST["params_1"]; 
  $params_2= $_POST["params_2"];
  $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,            
            );
  if( insertData('select',$queryData)==1){ 
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>date( 'Y-m-d H:i:s', time () ),
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('update',$queryData);
  }else{  
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>$_POST['currentTime'],
            'intime'=>$_POST['currentTime'],
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('insert',$queryData);
  }
    //echo "1";
    exit;
}
//click count
if (isset($_POST["call"]) && $_POST["call"] == "click" && isset($_POST["tid"]) && isset($_POST["tip"])) {
    
    $t_id = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tid"]);
    $t_ip = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tip"]);
    $clickCount = $_POST["clickCount"];
  $params_1= $_POST["params_1"]; 
  $params_2= $_POST["params_2"];
  $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,            
            );
  if( insertData('select',$queryData)==1){ 
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>date( 'Y-m-d H:i:s', time () ),
            'clickcount'=>$clickCount,
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('clickupdate',$queryData);
  }else{  
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>$_POST['currentTime'],
            'intime'=>$_POST['currentTime'],
            'clickcount'=>$clickCount,
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('clickinsert',$queryData);
  }
    exit;
}

//Mouse count
if (isset($_POST["call"]) && $_POST["call"] == "mouseCount" && isset($_POST["tid"]) && isset($_POST["tip"])) {
    
    $t_id = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tid"]);
    $t_ip = preg_replace("/[^A-Za-z0-9_.-]/", "", $_POST["tip"]);
    $mouseCount = $_POST["mouseCount"];
  $params_1= $_POST["params_1"]; 
  $params_2= $_POST["params_2"];
  $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,            
            );
  if( insertData('select',$queryData)==1){ 
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>date( 'Y-m-d H:i:s', time () ),
            'mousecount'=>$mouseCount,
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('mouseupdate',$queryData);
  }else{  
    $queryData= array(
            't1'=>$t_id,
            'ip'=>$t_ip,
            'outtime'=>$_POST['currentTime'],
            'intime'=>$_POST['currentTime'],
            'mousecount'=>$mouseCount,
            'params_1'=>$params_1,
            'params_2'=>$params_2
            );
    insertData('mouseinsert',$queryData);
  }
    exit;
}
// if something goes wrong
echo "0";
exit;
?>
<?php

function insertData($queryType,$queryData){
   $servername = "3.22.138.43";
  $username = "usertime";
  $password = "Ankush@gupta@12";
  $dbname = "mydb";
  $port = "3306";
$date = date('Y-m-d');
  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname, $port);
  
  // Check connection 
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
   if($queryType == 'insert'){   
     $sql = "INSERT INTO usertime (t1, ip, intime,outtime,params_1,params_2)  VALUES ('".$queryData['t1']."', '".$queryData['ip']."', '".$queryData['intime']."', '".$queryData['outtime']."', '".$queryData['params_1']."', '".$queryData['params_2']."')";
    return $conn->query($sql);
   }
   if($queryType == 'update'){     
     $sql = "UPDATE usertime SET outtime='".$queryData['outtime']."' WHERE  t1='".$queryData['t1']."' AND ip='".$queryData['ip']."' AND date(created_at)='$date'";
    return $conn->query($sql); 
   }
  if($queryType == 'select'){
    
     $sql = "SELECT * FROM usertime where t1='".$queryData['t1']."' AND ip='".$queryData['ip']."' AND date(created_at)='$date'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
     return 1;
    } else {
      return 0;
    }  
   }

  //Click count 

   if($queryType == 'clickinsert'){  
     $sql = "INSERT INTO usertime (t1, ip, intime,outtime,clickcount,params_1,params_2) VALUES ('".$queryData['t1']."', '".$queryData['ip']."', '".$queryData['intime']."', '".$queryData['outtime']."', '".$queryData['clickcount']."', '".$queryData['params_1']."', '".$queryData['params_2']."')";
    return $conn->query($sql);
   }
   if($queryType == 'clickupdate'){  
     $sql = "UPDATE usertime SET outtime='".$queryData['outtime']."', clickcount='".$queryData['clickcount']."' WHERE  t1='".$queryData['t1']."' AND ip='".$queryData['ip']."' AND date(created_at)='$date'";
    return $conn->query($sql); 
   }
   // Mouse count

   if($queryType == 'mouseinsert'){  
     $sql = "INSERT INTO usertime (t1, ip, intime,outtime,mousecount,params_1,params_2) VALUES ('".$queryData['t1']."', '".$queryData['ip']."', '".$queryData['intime']."', '".$queryData['outtime']."', '".$queryData['mousecount']."', '".$queryData['params_1']."', '".$queryData['params_2']."')";
    return $conn->query($sql);
   }
   if($queryType == 'mouseupdate'){  
     $sql = "UPDATE usertime SET outtime='".$queryData['outtime']."', mousecount='".$queryData['mousecount']."' WHERE  t1='".$queryData['t1']."' AND ip='".$queryData['ip']."' AND date(created_at)='$date'";
    return $conn->query($sql); 
   }
$conn->close(); 
}

?>