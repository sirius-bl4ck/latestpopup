<?php
//print_r($_GET);
date_default_timezone_set('US/Eastern');
$timezone = date_default_timezone_get();
$currentTime = date( 'Y-m-d H:i:s', time () );
$tid = $_GET['t1'];
$ip = $_GET['ip'];
$browser_name = $_GET['browser_name'];
$campaign_name = $_GET['campaign_name']; 
?>

   <!-- include JQuery -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

   
   <script>
   // set the TID
   var tid = "<?php echo $tid;?>"; 
   var tip = "<?php echo $ip;?>";
   var p1 = "<?php echo $browser_name;?>";
   var p2 = "<?php echo $campaign_name;?>";
   // set the timer accuracy - ex. 5 seconds
   var TIMER_ACCURACY = 5000;
   var currentTime = "<?php echo $currentTime;?>";
   // create the counter function
   (function(UI, PID, TA,p1,p2){
      // cal the PHP file every x seconds
      var I = setInterval(function(){
        // use AJAX so the page doesn't need to reload
        $.ajax({
          method:"post",
          url:"https://lockdownpart4.monster/TJ/TJpool/nimdaUS-Adult/dynamicpopup/ajax.php", // this is the link to the PHP file
          data:{call:"counter", tid: UI, tip:PID, currentTime:currentTime, params_1:p1, params_2:p2}
        })
        .fail() // put some code here if server is unreachable
        .done(); // put some code here to check server response
      }, TA);
   })(tid, tip, TIMER_ACCURACY,p1,p2);
   var clickCount = 0;
   $('body').click(function(){ 
   clickCount = clickCount + 1;
   $.ajax({
          method:"post",
          url:"https://lockdownpart4.monster/TJ/TJpool/nimdaUS-Adult/dynamicpopup/ajax.php", // this is the link to the PHP file
          data:{call:"click", tid: tid, tip:tip, currentTime:currentTime, clickCount:clickCount, params_1:p1, params_2:p2}
        })
   });
   var mouseCount = 0 ;
$('html').mouseover(function() {
  mouseCount = mouseCount + 1;
   $.ajax({
          method:"post",
          url:"https://lockdownpart4.monster/TJ/TJpool/nimdaUS-Adult/dynamicpopup/ajax.php", // this is the link to the PHP file
          data:{call:"mouseCount", tid: tid, tip:tip, currentTime:currentTime, mouseCount:mouseCount, params_1:p1, params_2:p2}
        })
});

   </script>

